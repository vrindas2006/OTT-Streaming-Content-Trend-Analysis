CREATE DATABASE ott_streaming_analysis;
SHOW DATABASES;
USE ott_streaming_analysis;
CREATE TABLE netflix_titles (
    show_id VARCHAR(20),
    type VARCHAR(20),
    title VARCHAR(255),
    director TEXT,
    cast TEXT,
    country TEXT,
    date_added DATE,
    release_year INT,
    rating VARCHAR(20),
    duration VARCHAR(50),
    listed_in TEXT,
    description TEXT,
    added_year INT,
    added_month INT,
    duration_value INT
);
SHOW TABLES;
DESCRIBE netflix_titles;
SELECT COUNT(*) AS total_rows FROM netflix_titles;
SELECT * FROM netflix_titles LIMIT 10;
SELECT 
    type,
    COUNT(*) AS number_of_titles
FROM netflix_titles
GROUP BY type
ORDER BY number_of_titles DESC;
SELECT COUNT(*) AS total_rows
FROM netflix_titles;
USE ott_streaming_analysis;

TRUNCATE TABLE netflix_titles;
SELECT COUNT(*) AS total_rows
FROM netflix_titles;
SHOW VARIABLES LIKE 'local_infile';

LOAD DATA LOCAL INFILE 'C:/Users/vsnai/Downloads/OTT_Netflix_Cleaned.csv'
INTO TABLE netflix_titles
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;
SELECT COUNT(*) AS total_rows
FROM netflix_titles;
SELECT show_id, COUNT(*) AS count
FROM netflix_titles
GROUP BY show_id
HAVING COUNT(*) > 1
ORDER BY count DESC;
DELETE t1
FROM netflix_titles t1
JOIN netflix_titles t2
  ON t1.show_id = t2.show_id
WHERE t1.show_id = t2.show_id
  AND t1.title = t2.title
  AND t1.type = t2.type
  AND t1.date_added = t2.date_added
  AND t1.release_year = t2.release_year
  AND t1.duration = t2.duration
  AND t1.added_year = t2.added_year
  AND t1.added_month = t2.added_month
  AND t1.duration_value = t2.duration_value
  AND t1.show_id IN (
      SELECT show_id
      FROM (
          SELECT show_id
          FROM netflix_titles
          GROUP BY show_id
          HAVING COUNT(*) > 1
      ) AS duplicates
  )
  AND t1.show_id > t2.show_id;
CREATE TABLE netflix_titles_backup AS
SELECT DISTINCT *
FROM netflix_titles;
TRUNCATE TABLE netflix_titles;
SELECT COUNT(*) AS total_rows
FROM netflix_titles;
LOAD DATA LOCAL INFILE 'C:/Users/vsnai/Downloads/OTT_Netflix_Cleaned.csv'
INTO TABLE netflix_titles
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(
    show_id,
    type,
    title,
    director,
    cast,
    country,
    @date_added,
    release_year,
    rating,
    duration,
    listed_in,
    description,
    @added_year,
    @added_month,
    @duration_value
)
SET
    date_added = NULLIF(@date_added, ''),
    added_year = NULLIF(@added_year, ''),
    added_month = NULLIF(@added_month, ''),
    duration_value = NULLIF(@duration_value, '');
SELECT COUNT(*) AS total_rows
FROM netflix_titles;
SELECT 
    type,
    COUNT(*) AS number_of_titles
FROM netflix_titles
GROUP BY type
ORDER BY number_of_titles DESC;

SELECT 
    added_year,
    COUNT(*) AS number_of_titles
FROM netflix_titles
WHERE added_year IS NOT NULL
GROUP BY added_year
ORDER BY added_year;
SELECT 'Dramas' AS genre, COUNT(*) AS number_of_titles
FROM netflix_titles
WHERE listed_in LIKE '%Dramas%'

UNION ALL

SELECT 'Comedies', COUNT(*)
FROM netflix_titles
WHERE listed_in LIKE '%Comedies%'

UNION ALL

SELECT 'Action & Adventure', COUNT(*)
FROM netflix_titles
WHERE listed_in LIKE '%Action & Adventure%'

UNION ALL

SELECT 'Documentaries', COUNT(*)
FROM netflix_titles
WHERE listed_in LIKE '%Documentaries%'

UNION ALL

SELECT 'International Movies', COUNT(*)
FROM netflix_titles
WHERE listed_in LIKE '%International Movies%'

UNION ALL

SELECT 'Independent Movies', COUNT(*)
FROM netflix_titles
WHERE listed_in LIKE '%Independent Movies%'

UNION ALL

SELECT 'Children & Family Movies', COUNT(*)
FROM netflix_titles
WHERE listed_in LIKE '%Children & Family Movies%'

UNION ALL

SELECT 'Thrillers', COUNT(*)
FROM netflix_titles
WHERE listed_in LIKE '%Thrillers%'

UNION ALL

SELECT 'Romantic Movies', COUNT(*)
FROM netflix_titles
WHERE listed_in LIKE '%Romantic Movies%'

UNION ALL

SELECT 'TV Dramas', COUNT(*)
FROM netflix_titles
WHERE listed_in LIKE '%TV Dramas%'

ORDER BY number_of_titles DESC;

SELECT 'United States' AS country, COUNT(*) AS number_of_titles
FROM netflix_titles
WHERE country LIKE '%United States%'

UNION ALL

SELECT 'India', COUNT(*)
FROM netflix_titles
WHERE country LIKE '%India%'

UNION ALL

SELECT 'United Kingdom', COUNT(*)
FROM netflix_titles
WHERE country LIKE '%United Kingdom%'

UNION ALL

SELECT 'Japan', COUNT(*)
FROM netflix_titles
WHERE country LIKE '%Japan%'

UNION ALL

SELECT 'South Korea', COUNT(*)
FROM netflix_titles
WHERE country LIKE '%South Korea%'

UNION ALL

SELECT 'Canada', COUNT(*)
FROM netflix_titles
WHERE country LIKE '%Canada%'

UNION ALL

SELECT 'France', COUNT(*)
FROM netflix_titles
WHERE country LIKE '%France%'

UNION ALL

SELECT 'Spain', COUNT(*)
FROM netflix_titles
WHERE country LIKE '%Spain%'

UNION ALL

SELECT 'Germany', COUNT(*)
FROM netflix_titles
WHERE country LIKE '%Germany%'

UNION ALL

SELECT 'Australia', COUNT(*)
FROM netflix_titles
WHERE country LIKE '%Australia%'

ORDER BY number_of_titles DESC;

SELECT 
    rating,
    COUNT(*) AS number_of_titles
FROM netflix_titles
WHERE rating IS NOT NULL
GROUP BY rating
ORDER BY number_of_titles DESC;

SELECT 
    ROUND(AVG(duration_value), 2) AS average_movie_duration_minutes
FROM netflix_titles
WHERE type = 'Movie'
  AND duration_value IS NOT NULL;
  
SELECT 
    release_year,
    COUNT(*) AS number_of_titles
FROM netflix_titles
WHERE release_year IS NOT NULL
GROUP BY release_year
ORDER BY release_year;

SELECT 
    release_year,
    type,
    COUNT(*) AS number_of_titles
FROM netflix_titles
WHERE release_year IS NOT NULL
GROUP BY release_year, type
ORDER BY release_year, type;